#ifndef SUMS_H_
#define SUMS_H_

double sum(int argc, char **argv);
double sum(char **argv, int argc);

#endif