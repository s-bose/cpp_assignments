#ifndef CALLFUNCTION_H_
#define CALLFUNCTION_H_

bool structCall(int argc, int argNum, char **argv);
void boundCall(int argc, int argNum, char **argv);

void usage(char const *programName);

#endif