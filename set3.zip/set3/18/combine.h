#ifndef COMBINE_H_
#define COMBINE_H_

#include "main.ih"

ReturnValues combine(int argc, int argNum, char **argv);

#endif