#ifndef UTILITIES_H_
#define UTILITIES_H_

#include <string>

size_t env_length(char **environ);

#endif